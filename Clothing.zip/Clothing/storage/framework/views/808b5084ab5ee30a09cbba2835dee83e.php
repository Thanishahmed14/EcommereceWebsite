<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <?php echo $__env->make('admin.admincss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </head>
  <body>
    <div class="container-scroller">
      <?php echo $__env->make('admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      
      








      <div class="row "  style="margin: 50px">
        <div class="col-12 grid-margin">
          <div class="card">
            <div class="card-body">
              <h4 class="card-title">USERS</h4>
              <div class="table-responsive">
                <table class="table" style="background-color: azure">
                  <thead>
                    <tr>
                      <th style="width: 150px" style="color: black"> Name </th>
                      <th style="width: 200px" style="color: black"> Email </th>
                      <th style="width: 150px" style="color: black">Update</th>
                      <th style="width: 150px" style="color: black">Delete</th>
                    </tr>
                  </thead>
                  <tbody>

                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                    
                    <tr>
                      <td style="color: black"><?php echo e($data->name); ?></td>
                      <td style="color: black"><?php echo e($data->email); ?></td>
                      <?php if($data->usertype==0): ?>
                      
                        <td><a href="<?php echo e(url('/updateuserview',$data->id)); ?>"><div class="badge badge-outline-warning">Update</div></a></td>
                      <td><a href="<?php echo e(url('/deleteuser',$data->id)); ?>"><div class="badge badge-outline-danger">Delete</div></a></td>
                      
                      <?php else: ?>
                      
                        <td style="color: black">Not Allowed</td>
                      <td style="color: black">Not Allowed</td>
                      
                         
                      <?php endif; ?>
                      
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>












    </div>
    <?php echo $__env->make('admin.adminscript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html><?php /**PATH C:\xampp\htdocs\Clothing\resources\views/admin/user.blade.php ENDPATH**/ ?>